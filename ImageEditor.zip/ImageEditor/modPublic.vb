﻿Module modPublic
    Friend SelectedIndex As Int32 = -1


End Module
