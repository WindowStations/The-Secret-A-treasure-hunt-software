﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmImage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tmrMessage = New System.Timers.Timer
        Me.lblClose = New System.Windows.Forms.Label
        Me.lblForeground = New System.Windows.Forms.Label
        Me.tmrColorFieldShift = New System.Timers.Timer
        Me.tmrOpacity = New System.Timers.Timer
        CType(Me.tmrMessage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tmrColorFieldShift, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tmrOpacity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrMessage
        '
        Me.tmrMessage.AutoReset = False
        Me.tmrMessage.Interval = 5000
        Me.tmrMessage.SynchronizingObject = Me
        '
        'lblClose
        '
        Me.lblClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblClose.BackColor = System.Drawing.Color.White
        Me.lblClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblClose.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClose.ForeColor = System.Drawing.Color.Black
        Me.lblClose.Location = New System.Drawing.Point(764, 12)
        Me.lblClose.Name = "lblClose"
        Me.lblClose.Size = New System.Drawing.Size(24, 24)
        Me.lblClose.TabIndex = 0
        Me.lblClose.Text = "X"
        Me.lblClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblClose.Visible = False
        '
        'lblForeground
        '
        Me.lblForeground.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblForeground.BackColor = System.Drawing.Color.Transparent
        Me.lblForeground.ForeColor = System.Drawing.Color.White
        Me.lblForeground.Location = New System.Drawing.Point(0, 0)
        Me.lblForeground.Name = "lblForeground"
        Me.lblForeground.Size = New System.Drawing.Size(794, 794)
        Me.lblForeground.TabIndex = 1
        '
        'tmrColorFieldShift
        '
        Me.tmrColorFieldShift.Enabled = True
        Me.tmrColorFieldShift.Interval = 200
        Me.tmrColorFieldShift.SynchronizingObject = Me
        '
        'tmrOpacity
        '
        Me.tmrOpacity.Enabled = True
        Me.tmrOpacity.Interval = 1
        Me.tmrOpacity.SynchronizingObject = Me
        '
        'frmImage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(800, 800)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblClose)
        Me.Controls.Add(Me.lblForeground)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmImage"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmImage"
        Me.TopMost = True
        CType(Me.tmrMessage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tmrColorFieldShift, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tmrOpacity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tmrMessage As System.Timers.Timer
    Friend WithEvents lblClose As System.Windows.Forms.Label
    Friend WithEvents lblForeground As System.Windows.Forms.Label
    Friend WithEvents tmrColorFieldShift As System.Timers.Timer
    Friend WithEvents tmrOpacity As System.Timers.Timer
End Class
