﻿Module modPublic
    Friend SelectedIndex As Int32 = -1
    Friend clrs(-1) As Color
End Module
