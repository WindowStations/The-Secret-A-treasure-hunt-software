﻿Imports System.Drawing.Imaging
Imports System.Windows
Imports System
Imports System.Runtime.InteropServices

Public Class frmImage
    Private Const HTCLIENT As Int32 = &H1
    Private Const HTCAPTION As Int32 = &H2
    Private Const WM_NCHITTEST As Int32 = &H84
    Private Const WM_NCLBUTTONDOWN As Integer = &HA1
    Private Const HTBORDER As Integer = 18
    Private Const HTBOTTOM As Integer = 15
    Private Const HTBOTTOMLEFT As Integer = 16
    Private Const HTBOTTOMRIGHT As Integer = 17
    Private Const HTLEFT As Integer = 10
    Private Const HTRIGHT As Integer = 11
    Private Const HTTOP As Integer = 12
    Private Const HTTOPLEFT As Integer = 13
    Private Const HTTOPRIGHT As Integer = 14
    Private Const BorderWidth As Integer = 6
    <DllImport("user32.dll")> _
    Public Shared Function ReleaseCapture() As Boolean
    End Function
    <DllImport("user32.dll")> _
    Public Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    End Function
    Friend imgdegree As Int32
    Friend img As Image = Nothing
    Friend imgupdown As Boolean = False
    Friend imgx As Int32 = 0
    Friend imgy As Int32 = 0
    Friend imgwidth As Double = 0
    Friend imgheight As Double = 0
    Friend imgPath As String = ""
    Friend imgOpacity As Double = 1
    Friend imgColorindex As Int32 = 0
    Friend imgShift As Boolean = False
    Friend imgFade As Boolean = False
    Friend imgFormFade As Boolean = False
    Friend imgShiftSpeed As Int32 = 200
    Friend imgFadeSpeed As Int32 = 50
    Friend imgFadeFormSpeed As Int32 = 50
    Friend opac As Double = 1
    Friend fadeout As Boolean = False
    Friend opac2 As Double = 1
    Friend fadeout2 As Boolean = False
    Private rd As RESIZE_DIRECTION = RESIZE_DIRECTION.None
    Private pt As New Point(-1, -1)
    Private txtMessage As String = ""
    Private Sub frmImage_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Array.Resize(clrs, 7)
        clrs(0) = Color.Red
        clrs(1) = Color.Orange
        clrs(2) = Color.Yellow
        clrs(3) = Color.Green
        clrs(4) = Color.Blue
        clrs(5) = Color.Indigo
        clrs(6) = Color.Violet
    End Sub
    Public Enum RESIZE_DIRECTION
        None = 0
        Left = 1
        TopLeft = 2
        Top = 3
        TopRight = 4
        Right = 5
        BottomRight = 6
        Bottom = 7
        BottomLeft = 8
    End Enum
    Public Property ResizeDirection() As RESIZE_DIRECTION
        Get
            Return rd
        End Get
        Set(ByVal value As RESIZE_DIRECTION)
            rd = value
            Select Case value
                Case RESIZE_DIRECTION.Left
                    Me.Cursor = Cursors.SizeWE
                Case RESIZE_DIRECTION.Right
                    Me.Cursor = Cursors.SizeWE
                Case RESIZE_DIRECTION.Top
                    Me.Cursor = Cursors.SizeNS
                Case RESIZE_DIRECTION.Bottom
                    Me.Cursor = Cursors.SizeNS
                Case RESIZE_DIRECTION.BottomLeft
                    Me.Cursor = Cursors.SizeNESW
                Case RESIZE_DIRECTION.TopRight
                    Me.Cursor = Cursors.SizeNESW
                Case RESIZE_DIRECTION.BottomRight
                    Me.Cursor = Cursors.SizeNWSE
                Case RESIZE_DIRECTION.TopLeft
                    Me.Cursor = Cursors.SizeNWSE
                Case Else
                    Me.Cursor = Cursors.Default
            End Select
        End Set
    End Property
    Private Sub frmImage_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        For i As Int32 = 0 To frmMDI.frms.Length - 1
            If frmMDI.frms(i) Is Me Then
                SelectedIndex = i
                Exit For
            End If
        Next
        frmMDI.isloaded = False
        frmMDI.lblSelected.Text = IO.Path.GetFileName(Me.imgPath)
        frmMDI.CheckBox1.Checked = Me.imgShift
        frmMDI.CheckBox2.Checked = Me.imgFade
        frmMDI.CheckBox3.Checked = Me.imgFormFade
        frmMDI.NumericUpDown1.Value = Me.imgShiftSpeed
        frmMDI.NumericUpDown2.Value = Me.imgFadeSpeed
        frmMDI.NumericUpDown3.Value = Me.imgFadeFormSpeed
        If Me.imgShift = False Then
            frmMDI.btnBrowse.Enabled = True
        Else
            frmMDI.btnBrowse.Enabled = False
        End If
        frmMDI.isloaded = True
    End Sub
    Private Sub frmImage_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = True
        Try
            Dim si As Int32 = 0
            For i As Int32 = 0 To frmMDI.frms.Length - 1
                If frmMDI.frms(i) Is Me Then
                    si = i
                    Exit For
                End If
            Next
            If si > frmMDI.tsImages.Items.Count - 1 Then
                si = frmMDI.tsImages.Items.Count - 1
            End If
            If si = -1 AndAlso frmMDI.tsImages.Items.Count > 0 Then
                si = 0
            End If
            If si = -1 Then Exit Sub
            Dim tmp(-1) As frmImage
            For z As Int32 = 0 To frmMDI.frms.Length - 1
                If z <> si Then
                    Array.Resize(tmp, tmp.Length + 1)
                    tmp(tmp.Length - 1) = frmMDI.frms(z)
                End If
            Next
            frmMDI.frms = tmp
            frmMDI.tsImages.Items.Item(si).Dispose()
        Catch ex As Exception
        End Try
        e.Cancel = False
    End Sub
    Private Sub frmImage_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left And Me.WindowState <> FormWindowState.Maximized Then
            ResizeForm(ResizeDirection)
        End If
    End Sub
    Private Sub frmImage_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        If e.Location.X < BorderWidth And e.Location.Y < BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.TopLeft
        ElseIf e.Location.X < BorderWidth And e.Location.Y > Me.Height - BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.BottomLeft
        ElseIf e.Location.X > Me.Width - BorderWidth And e.Location.Y < BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.TopRight
        ElseIf e.Location.X > Me.Width - BorderWidth And e.Location.Y > Me.Height - BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.BottomRight
        ElseIf e.Location.X > Me.Width - BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.Right
        ElseIf e.Location.Y > Me.Height - BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.Bottom
        ElseIf e.Location.X < BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.Left
        ElseIf e.Location.Y < BorderWidth Then
            ResizeDirection = RESIZE_DIRECTION.Top
        Else
            ResizeDirection = RESIZE_DIRECTION.None
        End If
    End Sub
    Private Sub frmImage_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseWheel
        If My.Computer.Keyboard.CtrlKeyDown = True Then
            Dim op As Double = 0
            Dim sdown As Boolean = My.Computer.Keyboard.ShiftKeyDown
            If sdown = True Then
                op = Me.Opacity
            Else
                op = frmMDI.frms(SelectedIndex).imgOpacity
            End If
            If e.Delta = Math.Abs(e.Delta) Then
                op += 0.01
            Else
                op -= 0.01
            End If
            If op < 0.01 Then op = 0.01
            If op > 1 Then op = 1
            If sdown = True Then
                If Me.Opacity <> op Then Me.Opacity = op
                txtMessage = "Form opacity: " & Math.Round(op, 3).ToString
            Else
                If frmMDI.frms(SelectedIndex).imgOpacity <> op Then frmMDI.frms(SelectedIndex).imgOpacity = op
                txtMessage = "Image opacity: " & Math.Round(op, 3).ToString
            End If
        Else
            If e.Delta = Math.Abs(e.Delta) Then
                Me.imgwidth -= 0.01
                Me.imgheight -= 0.01
            Else
                Me.imgwidth += 0.01
                Me.imgheight += 0.01
            End If
            txtMessage = "Width: " & Math.Round(Me.imgwidth, 3).ToString & " Height: " & Math.Round(Me.imgheight, 3).ToString
        End If
        RefreshImage()
    End Sub
    Private Sub frmImage_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles Me.PreviewKeyDown
        If e.Alt = True Then
            frmMDI.TopMost = True
            frmMDI.Focus()
        End If
    End Sub
    Private Sub RefreshImage()
        tmrMessage.Enabled = False
        tmrMessage.Enabled = True
        Me.Invalidate()
    End Sub
    Private Sub lblForeground_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles lblForeground.Paint
        On Error Resume Next
        If img Is Nothing Then Exit Sub
        Dim colormatrix As New Imaging.ColorMatrix
        Dim imgAttribute As New System.Drawing.Imaging.ImageAttributes
        colormatrix.Matrix33 = imgOpacity
        imgAttribute.SetColorMatrix(colormatrix, System.Drawing.Imaging.ColorMatrixFlag.[Default], System.Drawing.Imaging.ColorAdjustType.Bitmap)
        '  e.Graphics.TranslateTransform(-imgwidth, -imgheight)
        e.Graphics.RotateTransform(imgdegree)
        Dim wr As Double = imgwidth  '(Me.Size.Width - 12) / img.Size.Width
        Dim hr As Double = imgheight '(Me.Size.Height - 12) / img.Size.Height
        Dim r1 As New Rectangle(0, 0, img.GetBounds(GraphicsUnit.Pixel).Width * wr, img.GetBounds(GraphicsUnit.Pixel).Height * hr)
        Dim r2 As New Rectangle(0, 0, img.GetBounds(GraphicsUnit.Pixel).Width, img.GetBounds(GraphicsUnit.Pixel).Height)
        r1.X = Me.imgx
        r2.Y = Me.imgy
        e.Graphics.DrawImage(img, r1, r2.X, r2.Y, r2.Width, r2.Height, GraphicsUnit.Pixel, imgAttribute)
        Dim f As New Font(Me.Font.Name, 16, FontStyle.Regular)
        Dim sz As SizeF = e.Graphics.MeasureString(txtMessage, f)
        e.Graphics.DrawString(txtMessage, f, Brushes.WhiteSmoke, (Me.Width / 2) - (sz.Width / 2), 0)
    End Sub
    Private Sub lblForeground_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblForeground.MouseDown
        If My.Computer.Keyboard.CtrlKeyDown = True Then
            pt = e.Location
        Else
            If e.Button = Windows.Forms.MouseButtons.Left And Me.WindowState <> FormWindowState.Maximized Then
                MoveForm()
            End If
        End If
    End Sub
    Private Sub lblForeground_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblForeground.MouseMove
        If My.Computer.Keyboard.CtrlKeyDown = True Then
            If pt.X <> -1 AndAlso pt.Y <> -1 Then
                Dim pt2 As Point = e.Location
                If My.Computer.Keyboard.ShiftKeyDown = True Then
                    Dim d As Int32 = Me.imgdegree
                    d -= (pt2.X - pt.X)
                    If d >= 360 Then d -= 360
                    If d <= -1 Then d += 360
                    Me.imgdegree = d
                    txtMessage = "Degree: " & d.ToString
                Else
                    Me.imgx += (pt2.X - pt.X)
                    Me.imgy -= (pt2.Y - pt.Y)
                    txtMessage = "x: " & imgx.ToString & ", y: " & imgy.ToString
                End If
                RefreshImage()
                pt = pt2
            End If
        Else
            ResizeDirection = RESIZE_DIRECTION.None
            If e.Location.X > lblClose.Left AndAlso e.Location.X < lblClose.Right AndAlso e.Location.Y < lblClose.Bottom AndAlso e.Location.Y > lblClose.Top Then
                If lblClose.Visible = False Then
                    lblClose.Visible = True
                End If
            Else
                If lblClose.Visible = True Then
                    lblClose.Visible = False
                End If
            End If
        End If
    End Sub
    Private Sub lblForeground_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblForeground.MouseUp
        pt = New Point(-1, -1)
    End Sub
    Private Sub lblClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblClose.Click
        Me.Close()
    End Sub
    Private Sub MoveForm()
        ReleaseCapture()
        SendMessage(Me.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0)
    End Sub
    Private Sub ResizeForm(ByVal rdir As RESIZE_DIRECTION)
        Dim direction As Int32 = -1
        Select Case rdir
            Case RESIZE_DIRECTION.Left
                direction = HTLEFT
            Case RESIZE_DIRECTION.TopLeft
                direction = HTTOPLEFT
            Case RESIZE_DIRECTION.Top
                direction = HTTOP
            Case RESIZE_DIRECTION.TopRight
                direction = HTTOPRIGHT
            Case RESIZE_DIRECTION.Right
                direction = HTRIGHT
            Case RESIZE_DIRECTION.BottomRight
                direction = HTBOTTOMRIGHT
            Case RESIZE_DIRECTION.Bottom
                direction = HTBOTTOM
            Case RESIZE_DIRECTION.BottomLeft
                direction = HTBOTTOMLEFT
        End Select
        If direction = -1 Then Exit Sub
        ReleaseCapture()
        SendMessage(Me.Handle, WM_NCLBUTTONDOWN, direction, 0)
    End Sub
    Private Sub tmrMessage_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles tmrMessage.Elapsed
        txtMessage = ""
        lblForeground.Invalidate()
    End Sub
    Private Sub tmrColorFieldShift_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles tmrColorFieldShift.Elapsed
        If Me.imgShift = True Then
            Me.imgColorindex += 1
            If Me.imgColorindex = 7 Then Me.imgColorindex = 0 'Rainbow
            Me.BackColor = clrs(Me.imgColorindex)
            Me.Invalidate()
        End If
    End Sub
    Private Sub tmrOpacity_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles tmrOpacity.Elapsed
        If Me.imgFade = True Then
            If Me.fadeout = True Then
                Me.opac -= 1
            Else
                Me.opac += 1
            End If
            If Me.opac = 100 Then
                Me.fadeout = True
            ElseIf Me.opac = 5 Then
                Me.fadeout = False
            End If
            If My.Computer.Keyboard.ShiftKeyDown = True Then
                Me.Opacity = Me.opac / 100
                Me.Invalidate()
            Else
                Me.imgOpacity = Me.opac / 100
                Me.lblForeground.Invalidate()
            End If
        End If
    End Sub
    Private Sub tmrOpacityForm_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles tmrOpacityForm.Elapsed
        If Me.imgFormFade = True Then
            If Me.fadeout2 = True Then
                Me.opac2 -= 1
            Else
                Me.opac2 += 1
            End If
            If Me.opac2 = 100 Then
                Me.fadeout2 = True
            ElseIf Me.opac2 = 5 Then
                Me.fadeout2 = False
            End If
            Me.Opacity = Me.opac2 / 100
            Me.Invalidate()
        End If
    End Sub


End Class
