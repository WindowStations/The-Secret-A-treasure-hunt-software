﻿Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Public Class frmMDI
    Friend isloaded As Boolean = False
    Friend frms(-1) As frmImage
    Private ofd As New OpenFileDialog
    Private sfd As New SaveFileDialog
    Private Sub MDIParent1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ofd.Title = "Add image"
        ofd.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Recent)
        sfd.Title = "Location to save current image"
        sfd.Filter = "Bitmap files (*.bmp)|*.bmp|All files (*.*)|*.*"
        sfd.InitialDirectory = Application.StartupPath
        isloaded = True
    End Sub
    Private Sub btnAddImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddImage.Click
        AddImage()
    End Sub
    Private Sub AddImage()
        Dim pth As String = ""
        If ofd.ShowDialog = DialogResult.OK Then
            pth = ofd.FileName()
            If IO.File.Exists(pth) = True Then
                isloaded = False
                Try
                    Array.Resize(frms, frms.Length + 1)
                    frms(frms.Length - 1) = New frmImage
                    frms(frms.Length - 1).img = Image.FromFile(pth)
                    frms(frms.Length - 1).imgPath = pth
                    frms(frms.Length - 1).imgdegree = 0
                    frms(frms.Length - 1).imgheight = 1
                    frms(frms.Length - 1).imgwidth = 1
                    frms(frms.Length - 1).Opacity = 1
                    frms(frms.Length - 1).imgOpacity = 1
                    frms(frms.Length - 1).imgShiftSpeed = 1000
                    frms(frms.Length - 1).imgFadeSpeed = 10
                    frms(frms.Length - 1).imgFadeFormSpeed = 50
                    frms(frms.Length - 1).Show()
                    tsImages.Items.Add(frms(frms.Length - 1).img)
                    ofd.InitialDirectory = IO.Path.GetDirectoryName(pth)
                    Label1.Visible = True
                    If GroupBox1.Enabled = False Then GroupBox1.Enabled = True
                Catch ex As Exception
                End Try
                isloaded = True
            End If
        End If
    End Sub
    Private Sub tsImages_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles tsImages.ItemClicked
        For i As Int32 = 0 To tsImages.Items.Count - 1
            If tsImages.Items.Item(i) Is e.ClickedItem Then
                SelectedIndex = i
                Exit For
            End If
        Next
        frms(SelectedIndex).Focus()
        frms(SelectedIndex).TopMost = True
        isloaded = False
        lblSelected.Text = IO.Path.GetFileName(frms(SelectedIndex).imgPath)
        CheckBox1.Checked = frms(SelectedIndex).imgShift
        CheckBox2.Checked = frms(SelectedIndex).imgFade
        CheckBox3.Checked = frms(SelectedIndex).imgFormFade
        NumericUpDown1.Value = frms(SelectedIndex).imgShiftSpeed
        NumericUpDown2.Value = frms(SelectedIndex).imgFadeSpeed
        NumericUpDown3.Value = frms(SelectedIndex).imgFadeFormSpeed
        isloaded = True
    End Sub
    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        If CheckBox1.Checked = True Then Exit Sub
        Dim cd As New ColorDialog
        If cd.ShowDialog = Windows.Forms.DialogResult.OK Then
            frms(SelectedIndex).BackColor = cd.Color
            frms(SelectedIndex).Invalidate()
        End If
    End Sub
    Private Sub btnSaveImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveImage.Click
        SaveImage()
    End Sub
    Private Sub SaveImage()
        If SelectedIndex > frms.Length - 1 Then
            SelectedIndex = frms.Length - 1
        End If
        If SelectedIndex = -1 Then Exit Sub
        Dim b As New Bitmap(frms(SelectedIndex).Width, frms(SelectedIndex).Height)
        frms(SelectedIndex).DrawToBitmap(b, frms(SelectedIndex).Bounds)
        sfd.FileName = IO.Path.GetFileName(frms(SelectedIndex).imgPath)
        If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
            b.Save(sfd.FileName)
            sfd.InitialDirectory = IO.Path.GetDirectoryName(sfd.FileName)
        End If
    End Sub
    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        If isloaded = False Then Exit Sub
        If SelectedIndex = -1 Then Exit Sub
        frms(SelectedIndex).tmrColorFieldShift.Interval = NumericUpDown1.Value
        frms(SelectedIndex).imgShiftSpeed = NumericUpDown1.Value
    End Sub
    Private Sub NumericUpDown2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown2.ValueChanged
        If isloaded = False Then Exit Sub
        If SelectedIndex = -1 Then Exit Sub
        frms(SelectedIndex).tmrOpacity.Interval = NumericUpDown2.Value
        frms(SelectedIndex).imgFadeSpeed = NumericUpDown2.Value
    End Sub
    Private Sub NumericUpDown3_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown3.ValueChanged
        If isloaded = False Then Exit Sub
        If SelectedIndex = -1 Then Exit Sub
        frms(SelectedIndex).tmrOpacityForm.Interval = NumericUpDown3.Value
        frms(SelectedIndex).imgFadeFormSpeed = NumericUpDown3.Value
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        frmAbout.Show()
    End Sub
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If isloaded = False Then Exit Sub
        If SelectedIndex = -1 Then Exit Sub
        frms(SelectedIndex).imgShift = CheckBox1.Checked
        frms(SelectedIndex).tmrColorFieldShift.Interval = NumericUpDown1.Value
        If frms(SelectedIndex).imgShift = False Then
            frms(SelectedIndex).BackColor = Color.FromArgb(64, 64, 64)
        End If
    End Sub
    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If isloaded = False Then Exit Sub
        If SelectedIndex = -1 Then Exit Sub
        frms(SelectedIndex).imgFade = CheckBox2.Checked
        frms(SelectedIndex).tmrOpacity.Interval = NumericUpDown2.Value
        If frms(SelectedIndex).imgFade = False Then
            frms(SelectedIndex).imgOpacity = 1
            frms(SelectedIndex).Invalidate()
        End If
    End Sub
    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If isloaded = False Then Exit Sub
        If SelectedIndex = -1 Then Exit Sub
        frms(SelectedIndex).imgFormFade = CheckBox3.Checked
        frms(SelectedIndex).tmrOpacityForm.Interval = NumericUpDown3.Value
        If frms(SelectedIndex).imgFormFade = False Then
            frms(SelectedIndex).Opacity = 1
            frms(SelectedIndex).Invalidate()
        End If
    End Sub
End Class

